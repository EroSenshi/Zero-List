document.addEventListener("DOMContentLoaded", async () => {
  
  
  document.addEventListener("DOMContentLoaded", async () => {
  
    document.getElementById("confirmarAgregarCurso").addEventListener("click", async () => {
      try {
        // Obtener el valor del input "nombreCurso"
        const nombreCurso = document.getElementById("nombreCurso").value;
        
        // Realizar una solicitud POST al servidor para agregar el curso
        const response = await fetch("/cursos/agregar", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ nombreCurso }), // Enviar el nombre del curso como JSON
        });
    
        // Manejar la respuesta del servidor
        const data = await response.json();
    
        if (data.message === "Curso agregado con éxito") {
          // Realiza alguna acción después de agregar el curso, como recargar la página o actualizar la lista de cursos
          console.log("Curso agregado con éxito");
          closeModal(); // Cierra el modal después de agregar el curso
        } else {
          console.error("Error al agregar el curso:", data.error);
        }
      } catch (error) {
        console.error("Error al agregar el curso:", error);
      }
    });
    
    // Resto del código...
  });
  
  
  
  document.getElementById("confirmarEntrarCurso").addEventListener("click", async () => {
    try {
      const idCurso = document.getElementById("idCurso").value;
      
      // Realizar una solicitud POST al servidor para entrar al curso
      const response = await fetch("/cursos/entrar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ idCurso }),
      });
  
      // Manejar la respuesta del servidor
      const data = await response.json();
  
      if (data.message === "Curso ingresado con éxito") {
        // Realiza alguna acción después de entrar al curso, como recargar la página o actualizar la lista de cursos
        console.log("Curso ingresado con éxito");
        closeModal(); // Cierra el modal después de entrar al curso
      } else {
        console.error("Error al entrar al curso:", data.error);
      }
    } catch (error) {
      console.error("Error al entrar al curso:", error);
    }
  });
  



});
